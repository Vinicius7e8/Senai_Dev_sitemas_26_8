﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chave_facil_Att
{
    public partial class ReservaSala : Form
    {
        public ReservaSala()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void RetirarSala(Button DDevolver, Button RRetirar, Panel RLayout) 
        { 
            DDevolver.Enabled = true;
            RRetirar.Enabled = true;
            RLayout.BackColor = Color.Red;
            ReservaSala frm = new ReservaSala();
            frm.ShowDialog();
            string nome = frm = frm.Bt_Retirar01;
            Bt_Retirar01.BackColor = Color.FromArgb(192, 0, 0);

        }

        private void Bt_Retirar01_Click(object sender, EventArgs e)
        {
            string nome01 = Txb_nome01.Text; 


        }

        private void Bt_Devolver_Click(object sender, EventArgs e)
        {

        }
    }
}
