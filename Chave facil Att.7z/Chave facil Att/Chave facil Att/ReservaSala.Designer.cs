﻿namespace Chave_facil_Att
{
    partial class ReservaSala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Gbx_Layout = new System.Windows.Forms.GroupBox();
            this.Gbx_imformaçãoSala01 = new System.Windows.Forms.GroupBox();
            this.Bt_Status01 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_Senha01 = new System.Windows.Forms.Label();
            this.Txb_nome01 = new System.Windows.Forms.TextBox();
            this.Txb_Senha01 = new System.Windows.Forms.TextBox();
            this.Bt_Retirar01 = new System.Windows.Forms.Button();
            this.Bt_Devolver = new System.Windows.Forms.Button();
            this.Txt_Nome01 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Txt_ = new System.Windows.Forms.Label();
            this.Txt_NumeroSala = new System.Windows.Forms.Label();
            this.Txt_NomeUsuario = new System.Windows.Forms.Label();
            this.Gbx_Layout.SuspendLayout();
            this.Gbx_imformaçãoSala01.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gbx_Layout
            // 
            this.Gbx_Layout.Controls.Add(this.Txt_NumeroSala);
            this.Gbx_Layout.Controls.Add(this.Bt_Devolver);
            this.Gbx_Layout.Controls.Add(this.Bt_Retirar01);
            this.Gbx_Layout.Controls.Add(this.Txb_Senha01);
            this.Gbx_Layout.Controls.Add(this.Txb_nome01);
            this.Gbx_Layout.Controls.Add(this.Txt_Senha01);
            this.Gbx_Layout.Controls.Add(this.label1);
            this.Gbx_Layout.Controls.Add(this.Bt_Status01);
            this.Gbx_Layout.Controls.Add(this.Gbx_imformaçãoSala01);
            this.Gbx_Layout.Location = new System.Drawing.Point(13, 13);
            this.Gbx_Layout.Name = "Gbx_Layout";
            this.Gbx_Layout.Size = new System.Drawing.Size(492, 316);
            this.Gbx_Layout.TabIndex = 0;
            this.Gbx_Layout.TabStop = false;
            // 
            // Gbx_imformaçãoSala01
            // 
            this.Gbx_imformaçãoSala01.Controls.Add(this.Txt_NomeUsuario);
            this.Gbx_imformaçãoSala01.Controls.Add(this.Txt_);
            this.Gbx_imformaçãoSala01.Controls.Add(this.label5);
            this.Gbx_imformaçãoSala01.Controls.Add(this.Txt_Nome01);
            this.Gbx_imformaçãoSala01.Location = new System.Drawing.Point(6, 19);
            this.Gbx_imformaçãoSala01.Name = "Gbx_imformaçãoSala01";
            this.Gbx_imformaçãoSala01.Size = new System.Drawing.Size(480, 73);
            this.Gbx_imformaçãoSala01.TabIndex = 0;
            this.Gbx_imformaçãoSala01.TabStop = false;
            this.Gbx_imformaçãoSala01.Text = "Dados";
            // 
            // Bt_Status01
            // 
            this.Bt_Status01.Location = new System.Drawing.Point(6, 98);
            this.Bt_Status01.Name = "Bt_Status01";
            this.Bt_Status01.Size = new System.Drawing.Size(480, 63);
            this.Bt_Status01.TabIndex = 1;
            this.Bt_Status01.Text = "Sala";
            this.Bt_Status01.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nome";
            // 
            // Txt_Senha01
            // 
            this.Txt_Senha01.AutoSize = true;
            this.Txt_Senha01.Location = new System.Drawing.Point(7, 208);
            this.Txt_Senha01.Name = "Txt_Senha01";
            this.Txt_Senha01.Size = new System.Drawing.Size(38, 13);
            this.Txt_Senha01.TabIndex = 3;
            this.Txt_Senha01.Text = "Senha";
            // 
            // Txb_nome01
            // 
            this.Txb_nome01.Location = new System.Drawing.Point(7, 185);
            this.Txb_nome01.Name = "Txb_nome01";
            this.Txb_nome01.Size = new System.Drawing.Size(479, 20);
            this.Txb_nome01.TabIndex = 4;
            // 
            // Txb_Senha01
            // 
            this.Txb_Senha01.Location = new System.Drawing.Point(6, 224);
            this.Txb_Senha01.Name = "Txb_Senha01";
            this.Txb_Senha01.Size = new System.Drawing.Size(479, 20);
            this.Txb_Senha01.TabIndex = 5;
            // 
            // Bt_Retirar01
            // 
            this.Bt_Retirar01.Location = new System.Drawing.Point(6, 269);
            this.Bt_Retirar01.Name = "Bt_Retirar01";
            this.Bt_Retirar01.Size = new System.Drawing.Size(75, 23);
            this.Bt_Retirar01.TabIndex = 6;
            this.Bt_Retirar01.Text = "Retirar";
            this.Bt_Retirar01.UseVisualStyleBackColor = true;
            this.Bt_Retirar01.Click += new System.EventHandler(this.Bt_Retirar01_Click);
            // 
            // Bt_Devolver
            // 
            this.Bt_Devolver.Location = new System.Drawing.Point(407, 269);
            this.Bt_Devolver.Name = "Bt_Devolver";
            this.Bt_Devolver.Size = new System.Drawing.Size(75, 23);
            this.Bt_Devolver.TabIndex = 7;
            this.Bt_Devolver.Text = "Devolver";
            this.Bt_Devolver.UseVisualStyleBackColor = true;
            this.Bt_Devolver.Click += new System.EventHandler(this.Bt_Devolver_Click);
            // 
            // Txt_Nome01
            // 
            this.Txt_Nome01.AutoSize = true;
            this.Txt_Nome01.Location = new System.Drawing.Point(7, 20);
            this.Txt_Nome01.Name = "Txt_Nome01";
            this.Txt_Nome01.Size = new System.Drawing.Size(35, 13);
            this.Txt_Nome01.TabIndex = 0;
            this.Txt_Nome01.Text = "Nome";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Data";
            // 
            // Txt_
            // 
            this.Txt_.AutoSize = true;
            this.Txt_.Location = new System.Drawing.Point(45, 46);
            this.Txt_.Name = "Txt_";
            this.Txt_.Size = new System.Drawing.Size(10, 13);
            this.Txt_.TabIndex = 3;
            this.Txt_.Text = ":";
            // 
            // Txt_NumeroSala
            // 
            this.Txt_NumeroSala.AutoSize = true;
            this.Txt_NumeroSala.Location = new System.Drawing.Point(257, 123);
            this.Txt_NumeroSala.Name = "Txt_NumeroSala";
            this.Txt_NumeroSala.Size = new System.Drawing.Size(19, 13);
            this.Txt_NumeroSala.TabIndex = 8;
            this.Txt_NumeroSala.Text = "01";
            // 
            // Txt_NomeUsuario
            // 
            this.Txt_NomeUsuario.AutoSize = true;
            this.Txt_NomeUsuario.Location = new System.Drawing.Point(46, 19);
            this.Txt_NomeUsuario.Name = "Txt_NomeUsuario";
            this.Txt_NomeUsuario.Size = new System.Drawing.Size(10, 13);
            this.Txt_NomeUsuario.TabIndex = 4;
            this.Txt_NomeUsuario.Text = ":";
            // 
            // ReservaSala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 341);
            this.Controls.Add(this.Gbx_Layout);
            this.Name = "ReservaSala";
            this.Text = "ReservaSala";
            this.Gbx_Layout.ResumeLayout(false);
            this.Gbx_Layout.PerformLayout();
            this.Gbx_imformaçãoSala01.ResumeLayout(false);
            this.Gbx_imformaçãoSala01.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Gbx_Layout;
        private System.Windows.Forms.Label Txt_NumeroSala;
        private System.Windows.Forms.Button Bt_Devolver;
        private System.Windows.Forms.Button Bt_Retirar01;
        private System.Windows.Forms.TextBox Txb_Senha01;
        private System.Windows.Forms.TextBox Txb_nome01;
        private System.Windows.Forms.Label Txt_Senha01;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Bt_Status01;
        private System.Windows.Forms.GroupBox Gbx_imformaçãoSala01;
        private System.Windows.Forms.Label Txt_;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Txt_Nome01;
        private System.Windows.Forms.Label Txt_NomeUsuario;
    }
}