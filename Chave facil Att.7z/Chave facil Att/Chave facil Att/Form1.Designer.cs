﻿namespace Chave_facil_Att
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dt_Data01 = new System.Windows.Forms.DateTimePicker();
            this.Txt_Data01 = new System.Windows.Forms.GroupBox();
            this.Gbx_cabecalho01 = new System.Windows.Forms.GroupBox();
            this.Gbx_Salas01 = new System.Windows.Forms.GroupBox();
            this.Bt_Sala01 = new System.Windows.Forms.Button();
            this.Gbx_GropdeSalas01 = new System.Windows.Forms.GroupBox();
            this.Txt_titulo = new System.Windows.Forms.Label();
            this.Txt_Data01.SuspendLayout();
            this.Gbx_cabecalho01.SuspendLayout();
            this.Gbx_Salas01.SuspendLayout();
            this.Gbx_GropdeSalas01.SuspendLayout();
            this.SuspendLayout();
            // 
            // Dt_Data01
            // 
            this.Dt_Data01.Location = new System.Drawing.Point(6, 15);
            this.Dt_Data01.Name = "Dt_Data01";
            this.Dt_Data01.Size = new System.Drawing.Size(307, 20);
            this.Dt_Data01.TabIndex = 0;
            // 
            // Txt_Data01
            // 
            this.Txt_Data01.Controls.Add(this.Dt_Data01);
            this.Txt_Data01.Location = new System.Drawing.Point(6, 15);
            this.Txt_Data01.Name = "Txt_Data01";
            this.Txt_Data01.Size = new System.Drawing.Size(319, 41);
            this.Txt_Data01.TabIndex = 2;
            this.Txt_Data01.TabStop = false;
            this.Txt_Data01.Text = "Data";
            this.Txt_Data01.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Gbx_cabecalho01
            // 
            this.Gbx_cabecalho01.Controls.Add(this.Txt_Data01);
            this.Gbx_cabecalho01.Location = new System.Drawing.Point(12, 12);
            this.Gbx_cabecalho01.Name = "Gbx_cabecalho01";
            this.Gbx_cabecalho01.Size = new System.Drawing.Size(1248, 62);
            this.Gbx_cabecalho01.TabIndex = 3;
            this.Gbx_cabecalho01.TabStop = false;
            // 
            // Gbx_Salas01
            // 
            this.Gbx_Salas01.Controls.Add(this.Gbx_GropdeSalas01);
            this.Gbx_Salas01.Location = new System.Drawing.Point(12, 81);
            this.Gbx_Salas01.Name = "Gbx_Salas01";
            this.Gbx_Salas01.Size = new System.Drawing.Size(1248, 271);
            this.Gbx_Salas01.TabIndex = 4;
            this.Gbx_Salas01.TabStop = false;
            this.Gbx_Salas01.Text = "Sala 1º Andar ";
            // 
            // Bt_Sala01
            // 
            this.Bt_Sala01.Location = new System.Drawing.Point(6, 10);
            this.Bt_Sala01.Name = "Bt_Sala01";
            this.Bt_Sala01.Size = new System.Drawing.Size(75, 23);
            this.Bt_Sala01.TabIndex = 0;
            this.Bt_Sala01.Text = "Sala 1";
            this.Bt_Sala01.UseVisualStyleBackColor = true;
            this.Bt_Sala01.Click += new System.EventHandler(this.Bt_Sala01_Click);
            // 
            // Gbx_GropdeSalas01
            // 
            this.Gbx_GropdeSalas01.Controls.Add(this.Bt_Sala01);
            this.Gbx_GropdeSalas01.Location = new System.Drawing.Point(6, 20);
            this.Gbx_GropdeSalas01.Name = "Gbx_GropdeSalas01";
            this.Gbx_GropdeSalas01.Size = new System.Drawing.Size(1236, 42);
            this.Gbx_GropdeSalas01.TabIndex = 0;
            this.Gbx_GropdeSalas01.TabStop = false;
            // 
            // Txt_titulo
            // 
            this.Txt_titulo.AutoSize = true;
            this.Txt_titulo.Location = new System.Drawing.Point(588, 9);
            this.Txt_titulo.Name = "Txt_titulo";
            this.Txt_titulo.Size = new System.Drawing.Size(80, 13);
            this.Txt_titulo.TabIndex = 3;
            this.Txt_titulo.Text = "SISTEMA FIEP";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 824);
            this.Controls.Add(this.Txt_titulo);
            this.Controls.Add(this.Gbx_Salas01);
            this.Controls.Add(this.Gbx_cabecalho01);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Txt_Data01.ResumeLayout(false);
            this.Gbx_cabecalho01.ResumeLayout(false);
            this.Gbx_Salas01.ResumeLayout(false);
            this.Gbx_GropdeSalas01.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker Dt_Data01;
        private System.Windows.Forms.GroupBox Txt_Data01;
        private System.Windows.Forms.GroupBox Gbx_cabecalho01;
        private System.Windows.Forms.GroupBox Gbx_Salas01;
        private System.Windows.Forms.GroupBox Gbx_GropdeSalas01;
        private System.Windows.Forms.Button Bt_Sala01;
        private System.Windows.Forms.Label Txt_titulo;
    }
}

