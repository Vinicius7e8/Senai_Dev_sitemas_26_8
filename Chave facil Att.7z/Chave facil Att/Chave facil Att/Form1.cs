﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chave_facil_Att
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Bt_Sala01_Click(object sender, EventArgs e)
        {
            
            var menu01 = new ReservaSala();
            menu01.Show();
            /*if (menu01.ShowDialog() == DialogResult.OK)'
            {
                Bt_Sala01.BackColor = Color.FromArgb(192, 0, 0);
            }*/
        }
    }
}
