﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chave_facil
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btdevolver1_Click(object sender, EventArgs e)
        {
            BtRetirar2.Enabled = true;
            btdevolver1.Enabled = false;
            PnSala01.BackColor = Color.FromArgb(0,192,0);
            TxttNome.Text = null;
            MessageBox.Show("Sala Devolvida");
            TxttNome.Text = null;


        }

        private void BtRetirar2_Click(object sender, EventArgs e)
        {
            BtRetirar2.Enabled = false;
            btdevolver1.Enabled = true;
            PnSala01.BackColor = Color.FromArgb(192,0,0); 
            string nome1 = textBox1.Text;
            MessageBox.Show("Sala reservada");
            textBox1.Text = null;
            TxttNome.Text = nome1;
            Txt_Digite.Text = "Digite o nome do locador";
            

            //(nome1);       
        }

        private void PnSala01_Click(object sender, EventArgs e)
        {
            
        }

        private void DtdateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DtdateTime1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxttNome_Click(object sender, EventArgs e)
        {

        }

        private void Txt_Digite_Click(object sender, EventArgs e)
        {

        }
    }
}
