﻿namespace Chave_facil
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.btdevolver1 = new System.Windows.Forms.Button();
            this.BtRetirar2 = new System.Windows.Forms.Button();
            this.PnSala01 = new System.Windows.Forms.Button();
            this.Txtdate01 = new System.Windows.Forms.Label();
            this.DtdateTime1 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.TxttNome = new System.Windows.Forms.Label();
            this.TXTlocador = new System.Windows.Forms.Label();
            this.Txt_Digite = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1491, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // btdevolver1
            // 
            this.btdevolver1.Enabled = false;
            this.btdevolver1.ForeColor = System.Drawing.Color.Black;
            this.btdevolver1.Location = new System.Drawing.Point(86, 130);
            this.btdevolver1.Name = "btdevolver1";
            this.btdevolver1.Size = new System.Drawing.Size(65, 36);
            this.btdevolver1.TabIndex = 5;
            this.btdevolver1.Text = "Devolver";
            this.btdevolver1.UseVisualStyleBackColor = true;
            this.btdevolver1.Click += new System.EventHandler(this.btdevolver1_Click);
            // 
            // BtRetirar2
            // 
            this.BtRetirar2.Location = new System.Drawing.Point(22, 130);
            this.BtRetirar2.Name = "BtRetirar2";
            this.BtRetirar2.Size = new System.Drawing.Size(65, 36);
            this.BtRetirar2.TabIndex = 6;
            this.BtRetirar2.Text = "Retirar";
            this.BtRetirar2.UseVisualStyleBackColor = true;
            this.BtRetirar2.Click += new System.EventHandler(this.BtRetirar2_Click);
            // 
            // PnSala01
            // 
            this.PnSala01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.PnSala01.Cursor = System.Windows.Forms.Cursors.Default;
            this.PnSala01.ForeColor = System.Drawing.Color.Snow;
            this.PnSala01.Location = new System.Drawing.Point(12, 38);
            this.PnSala01.Name = "PnSala01";
            this.PnSala01.Size = new System.Drawing.Size(155, 170);
            this.PnSala01.TabIndex = 7;
            this.PnSala01.Text = "Sala 1";
            this.PnSala01.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.PnSala01.UseVisualStyleBackColor = false;
            this.PnSala01.Click += new System.EventHandler(this.PnSala01_Click);
            // 
            // Txtdate01
            // 
            this.Txtdate01.AutoSize = true;
            this.Txtdate01.Location = new System.Drawing.Point(12, 18);
            this.Txtdate01.Name = "Txtdate01";
            this.Txtdate01.Size = new System.Drawing.Size(30, 13);
            this.Txtdate01.TabIndex = 8;
            this.Txtdate01.Text = "Data";
            // 
            // DtdateTime1
            // 
            this.DtdateTime1.Location = new System.Drawing.Point(48, 12);
            this.DtdateTime1.Name = "DtdateTime1";
            this.DtdateTime1.Size = new System.Drawing.Size(229, 20);
            this.DtdateTime1.TabIndex = 10;
            this.DtdateTime1.ValueChanged += new System.EventHandler(this.DtdateTime1_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(38, 104);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 14;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TxttNome
            // 
            this.TxttNome.AutoSize = true;
            this.TxttNome.BackColor = System.Drawing.Color.Transparent;
            this.TxttNome.Location = new System.Drawing.Point(78, 64);
            this.TxttNome.Name = "TxttNome";
            this.TxttNome.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TxttNome.Size = new System.Drawing.Size(9, 13);
            this.TxttNome.TabIndex = 15;
            this.TxttNome.Text = "|";
            this.TxttNome.Click += new System.EventHandler(this.TxttNome_Click);
            // 
            // TXTlocador
            // 
            this.TXTlocador.AutoSize = true;
            this.TXTlocador.BackColor = System.Drawing.Color.Transparent;
            this.TXTlocador.Location = new System.Drawing.Point(26, 64);
            this.TXTlocador.Name = "TXTlocador";
            this.TXTlocador.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TXTlocador.Size = new System.Drawing.Size(46, 13);
            this.TXTlocador.TabIndex = 16;
            this.TXTlocador.Text = "Locador";
            // 
            // Txt_Digite
            // 
            this.Txt_Digite.AutoSize = true;
            this.Txt_Digite.BackColor = System.Drawing.Color.Transparent;
            this.Txt_Digite.Location = new System.Drawing.Point(26, 88);
            this.Txt_Digite.Name = "Txt_Digite";
            this.Txt_Digite.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Txt_Digite.Size = new System.Drawing.Size(125, 13);
            this.Txt_Digite.TabIndex = 17;
            this.Txt_Digite.Text = "Digite o nome do locador";
            this.Txt_Digite.Click += new System.EventHandler(this.Txt_Digite_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1491, 613);
            this.Controls.Add(this.Txt_Digite);
            this.Controls.Add(this.TXTlocador);
            this.Controls.Add(this.TxttNome);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.DtdateTime1);
            this.Controls.Add(this.Txtdate01);
            this.Controls.Add(this.BtRetirar2);
            this.Controls.Add(this.btdevolver1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.PnSala01);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button btdevolver1;
        private System.Windows.Forms.Button BtRetirar2;
        private System.Windows.Forms.Button PnSala01;
        private System.Windows.Forms.Label Txtdate01;
        private System.Windows.Forms.DateTimePicker DtdateTime1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label TxttNome;
        private System.Windows.Forms.Label TXTlocador;
        private System.Windows.Forms.Label Txt_Digite;
    }
}

// txt textos / Dt data / PN NomedoPainel / Bt NomeDobotão / Frm NomeDaforma / LBL NomeDoRotulo 
